{ 8-bit port and external peripheral devices }

unit Port;

interface

  var
    pd, pe, pdi: byte;
    PrinterData: byte;
    SerialRate: integer = 10000;	{ value not important, but not 0 }

  function ReadPd : byte;
  procedure WritePd;
  procedure IoInit;
  procedure IoClose;
  function IoWrPtr (index: integer) : pointer;
  function IoRdPtr (index: integer) : pointer;
  procedure OnSerialTick;

implementation

  uses Def, Main, Cpu, Comm;

var
  ga_rd: array[0..7] of byte;
  ga_wr2, ga_wr3, ga_wr6: byte;
  SerialLength: integer = 0;
  TxCounter: integer = 0;
  RxCounter: integer = 0;
  RxData: integer;
  OldPort: byte;

function GetPort: byte;
begin
  GetPort := (pd and pe) or (pdi and not pe);
end {GetPort};


function ReadPd : byte;
begin
  ReadPd := GetPort;
end {ReadPd};


procedure WritePd;
var
  x: byte;
begin
  x := GetPort;
  if ((x and $08) <> 0) and ((OldPort and $08) = 0) then
{ Printer Strobe has changed from 0 to 1 }
  begin
    CommWrite (PrinterData);
  end {if};
  OldPort := x;
end {WritePd};


procedure IoInit;
begin
  if Option2 = 0 then pdi := $9F else pdi := $DF;	{Printer always Ready}
  OldPort := GetPort;
  ga_rd[0] := $FF;
  ga_rd[1] := $FF;
  ga_rd[2] := 0;
  ga_rd[3] := $05;
  ga_rd[4] := 0;
  ga_rd[5] := $FF;
  ga_rd[6] := 0;
  ga_rd[7] := $FF;
  ga_wr3 := 0;
  ga_wr6 := 0;
end {IoInit};


procedure IoClose;
begin
end {IoClose};


procedure OnWriteDataReg;
begin
  if (ga_rd[4] and $90) = $80 then	{transmitter enabled, no MT}
  begin
    ga_rd[3] := ga_rd[3] and $FE;	{transmitter busy}
    TxCounter := SerialLength;
  end {if};
end {OnWriteDataReg};


procedure OnReadDataReg;
begin
  ga_rd[3] := ga_rd[3] and $C5;	{clear the errors and the RX buffer full flag}
  ky := ky or $0800;		{release INT1}
end {OnReadDataReg};


procedure BaudRateSetting;
const
  baud_div: array[0..7] of integer = (
	(1000 * XTAL ) div 9600,
	(1000 * XTAL ) div 4800,
	(1000 * XTAL ) div 2400,
	(1000 * XTAL ) div 1200,
	(1000 * XTAL ) div 600,
	(1000 * XTAL ) div 300,
	(1000 * XTAL ) div 150,
	(1000 * XTAL ) div 75 );
begin
  SerialRate := baud_div[ga_rd[4] and 7];
end {BaudRateSetting};


procedure LengthSetting;
begin
  if (ga_wr3 and $40) <> 0 then
  begin
    SerialLength := 9;	{ 1 start bit + 7 data bits + 1 stop bit }
    if (ga_wr3 and $04) <> 0 then Inc(SerialLength);	{ 8 data bits }
    if (ga_wr3 and $10) <> 0 then Inc(SerialLength);	{ 1 parity bit }
    if (ga_wr3 and $80) <> 0 then Inc(SerialLength);	{ 2 stop bits }
  end {if};
end {LengthSetting};


function IoWrPtr (index: integer) : pointer;
begin
  index := index and 7;
  case index of
    2: begin
         IoWrPtr := @ga_wr2;
         procptr[procindex] := @OnWriteDataReg;
         Inc(procindex);
       end;
    3: begin
         IoWrPtr := @ga_wr3;
         procptr[procindex] := @LengthSetting;
         Inc(procindex);
       end;
    4: begin
         IoWrPtr := @ga_rd[4];
         procptr[procindex] := @BaudRateSetting;
         Inc(procindex);
       end;
    5, 7: IoWrPtr := @ga_rd[index];
  else
    IoWrPtr := @dummydst;
  end {case};
end {IoWrPtr};


function IoRdPtr (index: integer) : pointer;
begin
  IoRdPtr := @ga_rd[index and 7];
  if index = 2 then
  begin
    procptr[procindex] := @OnReadDataReg;
    Inc(procindex);
  end {if};
end {IoRdPtr};


{ called at the serial bit rate }
procedure OnSerialTick;
begin
  if TxCounter > 0 then
  begin
    Dec(TxCounter);
    if TxCounter = 0 then
    begin
      CommWrite (ga_wr2);
      ga_rd[3] := ga_rd[3] or $01;	{transmitter ready}
    end {if};
  end {if};

  if (ga_rd[4] and $50) = $40 then	{receiver enabled, no MT}
  begin
    if RxCounter = 0 then
    begin
      RxData := CommRead;
      if RxData >= 0 then RxCounter := SerialLength;
    end {if};
    if RxCounter > 0 then
    begin
      Dec(RxCounter);
      if RxCounter = 0 then
      begin
        ga_rd[2] := byte(RxData);
        ky := ky and not $0800;		{trigger INT1}
        if (ga_rd[3] and $02) = 0 then
          ga_rd[3] := ga_rd[3] or $02	{RX buffer full}
        else
          ga_rd[3] := ga_rd[3] or $10;	{overrun error}
      end {if};
    end {if};
  end {if};
end {OnSerialTick};

end.

